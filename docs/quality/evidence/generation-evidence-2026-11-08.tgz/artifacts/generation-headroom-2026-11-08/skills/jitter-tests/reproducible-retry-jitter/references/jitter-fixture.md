Python標準ライブラリのみを使う設計用fixture。今回実行していない。将来、権限のあるローカル環境で通常のassertを有効にして実行し、全assertを通過した正常終了を合格とする。失敗時は停止する。対象実装や実際の待機動作の合格を証明するものではない。

```python
import math
import random


def delay(base, jitterRatio, rng):
    if not math.isfinite(base) or base < 0:
        raise ValueError('invalid base')
    if not math.isfinite(jitterRatio):
        raise ValueError('invalid ratio')
    r = min(1.0, max(0.0, jitterRatio))
    if r == 0 or base == 0:
        return base
    u = rng()
    if not math.isfinite(u) or not 0 <= u <= 1:
        raise ValueError('invalid random value')
    value = base * (1 + r * (2 * u - 1))
    if not math.isfinite(value):
        raise ValueError('delay overflow')
    return value


def forbidden_rng():
    raise AssertionError('unexpected RNG call')


def rejects(action):
    try:
        action()
    except ValueError:
        return
    raise AssertionError('expected ValueError')


# 合成入力と固定期待値。端点1は注入試験用にも許容する。
for ratio in (-0.2, 0):
    assert delay(100, ratio, forbidden_rng) == 100
assert delay(0, 0.25, forbidden_rng) == 0
for ratio, expected in (
    (0.25, [75, 100, 125]),
    (1, [0, 100, 200]),
    (1.5, [0, 100, 200]),
):
    actual = [delay(100, ratio, lambda u=u: u)
              for u in (0.0, 0.5, 1.0)]
    assert actual == expected

# 同一シードの独立インスタンスで列を再現する。
a, b = random.Random(7), random.Random(7)
xs = [delay(100, 0.25, a.random) for _ in range(20)]
ys = [delay(100, 0.25, b.random) for _ in range(20)]
assert xs == ys
assert all(75 <= x <= 125 for x in xs)

# 意図的な契約違反を検出する負例。
for ratio in (float('nan'), float('inf'), -float('inf')):
    rejects(lambda ratio=ratio: delay(100, ratio, forbidden_rng))
for base in (-1, float('nan'), float('inf')):
    rejects(lambda base=base: delay(base, 0, forbidden_rng))
for u in (-0.01, 1.01, float('nan'), float('inf')):
    rejects(lambda u=u: delay(100, 0.25, lambda: u))
rejects(lambda: delay(1e308, 1, lambda: 1.0))
# 全assert通過後、暗黙の終了コード0で終了する。
```

同一シードによる列の一致は同一の乱数実装・版の範囲で判定する。版をまたぐ固定期待値にはシード列ではなく、明示した乱数値を注入する。
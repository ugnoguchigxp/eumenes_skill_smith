### 用途と限界
手順3で読む。Python標準ライブラリだけで、秘密を含む入力から許可リスト方式で診断出力を組み立てる例。対象製品のAPIや既存redactorの代用ではない。現在は未実行であり、実行時に全assertを通り正常終了した場合だけこのfixtureの合格とする。外部通信・ファイル操作はない。

```python
import copy
import json
from urllib.parse import quote

secrets = ('META_SECRET_1', 'OLD_SECRET_2', 'NEW_SECRET_3',
           'URL/SECRET+4', 'AUTH_SECRET_5', 'KEY_SECRET_6')
event = {
    'stage': 'decode', 'status': 'error', 'count': 2,
    'metadata': {'nested': [{'token': secrets[0]},
                            {'privateKey': secrets[5]}]},
    'diff': [{'old': secrets[1], 'new': secrets[2]}],
    'url': '/task?token=' + quote(secrets[3], safe=''),
    'Authorization': 'Bearer ' + secrets[4],
}
before = copy.deepcopy(event)

# このfixtureの診断契約だけを実装する。任意文字列を転送しない。
def diagnostic(x):
    if x.get('stage') not in ('decode', 'validate'):
        raise ValueError('unsupported stage')
    if x.get('status') not in ('ok', 'error'):
        raise ValueError('unsupported status')
    if type(x.get('count')) is not int or not 0 <= x['count'] <= 100:
        raise ValueError('unsupported count')
    return {k: x[k] for k in ('stage', 'status', 'count')}

# 最終的に出力する直列化結果を検査する。
variants = tuple(v for s in secrets for v in (s, quote(s, safe='')))
def no_secret(serialized):
    return not any(v in serialized for v in variants)

out = diagnostic(event)
assert out == {'stage': 'decode', 'status': 'error', 'count': 2}
assert event == before
assert no_secret(json.dumps(out, ensure_ascii=False))

# 負例：未加工入力の流出と、許可項目への秘密の混入を検出する。
assert not no_secret(json.dumps(event, ensure_ascii=False))
for secret in secrets:
    assert not no_secret(json.dumps({'leak': secret}))
    assert not no_secret(json.dumps({'leak': quote(secret, safe='')}))
bad = dict(event, stage=secrets[0])
try:
    diagnostic(bad)
except ValueError:
    pass
else:
    raise AssertionError('secret-bearing stage accepted')
```

この例は許可した3項目以外を出力しないため、metadataやdiffそのもののredaction精度は測定しない。対象実装では、既存フィルタを通したmetadata・diffを含む実際の最終出力を別途検査する。
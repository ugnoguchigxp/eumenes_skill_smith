標準Pythonだけで、計画上の許可境界を検査する合成例。実機、移行ツール、権限管理の代用品ではない。今回未実行であり、権限のある呼出側が将来必要なら利用する。
```python
from copy import deepcopy

base = {
    'phase': 'document',
    'target_known': False,
    'read_authorized': False,
    'backup_authorized': False,
    'dry_run_verified': False,
    'stop_authorized': False,
    'write_authorized': False,
}

def allowed(p):
    if p['phase'] == 'document':
        return {'draft'}
    if p['phase'] != 'preflight':
        return set()  # cutoverはこの検査の対象外
    if not (p['target_known'] and p['read_authorized']):
        return set()
    actions = {'read_counts'}
    if p['backup_authorized']:
        actions.add('backup')
    if p['dry_run_verified']:
        actions.add('dry_run')
    return actions

cases = [
    ({}, {'draft'}),
    ({'phase': 'preflight'}, set()),
    ({'phase': 'preflight', 'target_known': True,
      'read_authorized': True}, {'read_counts'}),
    ({'phase': 'preflight', 'target_known': True,
      'read_authorized': True, 'backup_authorized': True,
      'dry_run_verified': True},
     {'read_counts', 'backup', 'dry_run'}),
    ({'phase': 'cutover', 'stop_authorized': True,
      'write_authorized': True}, set()),
]
for changes, expected in cases:
    p = deepcopy(base)
    p.update(changes)
    assert allowed(p) == expected
    assert not ({'stop_daemon', 'write_migration', 'drop_tables'} & allowed(p))

# 負例：今日の計画へ停止を混ぜると拒否される。
def validate_plan(actions, p):
    if not actions <= allowed(p):
        raise ValueError('操作範囲外')

validate_plan({'draft'}, base)
try:
    validate_plan({'draft', 'stop_daemon'}, base)
except ValueError:
    pass
else:
    raise AssertionError('禁止操作を検出できない')
print('計画境界の合成検査完了')
```
期待値は各集合との完全一致と負例の拒否。assert失敗または例外の取り逃しで検査を停止し、正常終了時だけこの合成検査の合格とする。対象環境のpreflightやcutoverの合格は示さない。
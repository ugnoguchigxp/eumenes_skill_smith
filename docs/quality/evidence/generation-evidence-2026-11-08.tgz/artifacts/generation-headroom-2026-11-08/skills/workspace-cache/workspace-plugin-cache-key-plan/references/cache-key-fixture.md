標準Pythonだけで扱う合成入力の例。実cache APIや実ファイルの解決を模造するものではなく、採用候補の直列化方式と不変条件を検査する。実行は将来、権限のある呼出側が行う。全assert成立後の正常終了が期待値であり、例外またはassert失敗なら終了条件を満たさない。

```python
import json

# 入力は呼出側が確定した識別子。ここではパス解決しない。
def key(root, config, plugins, config_revision):
    if not root or not config or not config_revision:
        raise ValueError('missing context')
    if any(len(p) != 2 or not all(p) for p in plugins):
        raise ValueError('missing plugin identity or revision')
    return json.dumps(
        ['config-cache-v1', root, config, config_revision,
         [list(p) for p in plugins]],
        ensure_ascii=True, separators=(',', ':'))

config = '/shared/config.json'
p = (('/plugins/a', 'a1'), ('/plugins/b', 'b1'))
a = key('/ws/a', config, p, 'c1')
b = key('/ws/b', config, p, 'c1')
changed = key('/ws/a', config, (('/plugins/a', 'a2'), p[1]), 'c1')
assert a == key('/ws/a', config, p, 'c1')
assert len({a, b, changed}) == 3
assert a != key('/ws/a', config, tuple(reversed(p)), 'c1')
assert a != key('/ws/a', config, p, 'c2')
assert a != key('/ws/a', '/other/config.json', p, 'c1')
assert key('/ws/a', config, (('a|b', 'c'),), 'c1') != key(
    '/ws/a', config, (('a', 'b|c'),), 'c1')
assert json.loads(a) == [
    'config-cache-v1', '/ws/a', config, 'c1',
    [['/plugins/a', 'a1'], ['/plugins/b', 'b1']]]

# 不正入力はキーを作らず拒否する。
try:
    key('', config, p, 'c1')
except ValueError:
    pass
else:
    raise AssertionError('invalid context accepted')

# 意図的な欠陥: configPathだけでは分離試験に不合格となる。
def rejects_mixing(make_key):
    try:
        assert make_key('/ws/a', config, p, 'c1') != make_key(
            '/ws/b', config, p, 'c1')
    except AssertionError:
        return True
    return False

assert rejects_mixing(lambda root, cfg, plugins, rev: cfg)
assert not rejects_mixing(key)
```

これは未実行のfixtureである。辞書を用いた実cacheの代用品は合格根拠にせず、実APIのヒット／ミス、並行性、値の所有権、失効は別途結合試験する。
標準JavaScriptとNode.js組込みのassertだけを使う未実行fixture。以下のrecordは提案する選択規則の例であり、対象orchestratorのAPIを再現したものではない。awaitできる完了契約を選んだ場合の分岐を検査するもので、既定retryの内部動作や実際の保存成功は検証しない。呼出側が権限のあるローカル環境で実行し、全assert成立で正常終了することを期待する。

```javascript
import assert from 'node:assert/strict';

async function record(deps, result, recordReviewResultWithRetry) {
  if (deps.recordReviewResultFn !== undefined) {
    if (typeof deps.recordReviewResultFn !== 'function') {
      throw new TypeError('recordReviewResultFn must be a function');
    }
    await deps.recordReviewResultFn(result);
  } else {
    await recordReviewResultWithRetry(result);
  }
}

const result = Object.freeze({ reviewId: 'fixture', outcome: 'ok' });
let injectedCalls = 0;
let defaultCalls = 0;
const fallback = async (value) => {
  assert.strictEqual(value, result);
  defaultCalls++;
};
const deps = {
  async recordReviewResultFn(value) {
    assert.strictEqual(this, deps);
    assert.strictEqual(value, result);
    injectedCalls++;
  }
};

await record(deps, result, fallback);
assert.equal(injectedCalls, 1);
assert.equal(defaultCalls, 0);
await record({}, result, fallback);
assert.equal(defaultCalls, 1);

const failure = new Error('fixture failure');
for (const fn of [
  () => { throw failure; },
  async () => { throw failure; }
]) {
  await assert.rejects(
    () => record({ recordReviewResultFn: fn }, result, fallback),
    (error) => error === failure
  );
}
assert.equal(defaultCalls, 1); // 失敗しても既定実装へ逃がさない
await assert.rejects(
  () => record({ recordReviewResultFn: null }, result, fallback),
  TypeError
);
assert.equal(defaultCalls, 1);
```

不正値nullの拒否は、このfixtureで採用した「省略はundefinedのみ」という契約の負例である。対象型がnullを許す場合はその契約に合わせて分岐と期待値を変える。assert失敗または未処理例外は不合格として終了し、実環境の呼出しへ進まない。
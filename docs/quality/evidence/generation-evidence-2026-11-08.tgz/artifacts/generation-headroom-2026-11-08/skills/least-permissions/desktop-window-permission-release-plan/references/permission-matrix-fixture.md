これは実アプリの設定ではなく、計画上の許可集合と候補集合を照合する標準Pythonの未実行例である。権限エンジンや資源スコープの実効性は検証しない。合成入力の正例・余分な許可・必要許可欠落を検出し、全assert通過時に終了コード0、違反の見逃し時にAssertionErrorで非正常終了する。
```python
from collections import namedtuple

Grant = namedtuple('Grant', 'window family operation scope')
# 合成入力。実環境の必要権限を表すものではない。
expected = frozenset({
    Grant('editor', 'filesystem', 'read', 'fixture-document'),
    Grant('worker', 'shell', 'execute', 'fixture-tool'),
    Grant('viewer', 'HTTP', 'GET', 'fixture-origin'),
    Grant('editor', 'clipboard', 'write', 'fixture-text'),
    Grant('editor', 'dialog', 'open', 'fixture-picker'),
})

def compare(candidate):
    candidate = frozenset(candidate)
    return candidate - expected, expected - candidate

assert compare(expected) == (frozenset(), frozenset())
extra = Grant('viewer', 'shell', 'execute', '*')
assert compare(expected | {extra}) == (
    frozenset({extra}), frozenset()
)
missing = Grant('editor', 'clipboard', 'write', 'fixture-text')
assert compare(expected - {missing}) == (
    frozenset(), frozenset({missing})
)
print('許可集合の正負照合完了')
```
実際の棚卸しでは、継承や共有設定を展開した実効許可を同等の列へ対応付ける。ワイルドカードの意味展開や実際の拒否結果は、この文字列集合の比較では証明できない。
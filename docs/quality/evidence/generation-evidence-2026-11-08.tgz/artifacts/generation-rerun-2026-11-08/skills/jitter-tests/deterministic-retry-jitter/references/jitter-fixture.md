Python 3標準ライブラリだけを使う、将来の許可されたローカル試験用の例。現在は未実行。純粋計算の契約を示すもので、対象実装や待機機構の動作を保証しない。上限クリップと整数時間への変換は含めない。

```python
import math


def delay(base, ratio, rng):
    if not math.isfinite(base) or base < 0:
        raise ValueError('base')
    if not math.isfinite(ratio):
        raise ValueError('ratio')
    r = min(1.0, max(0.0, ratio))
    if r == 0 or base == 0:
        return base
    u = rng()
    if not math.isfinite(u) or not 0 <= u <= 1:
        raise ValueError('rng')
    value = base * ((1 - r) + 2 * r * u)
    if not math.isfinite(value):
        raise ValueError('overflow')
    return value


class Fixed:
    def __init__(self, value):
        self.value = value
        self.calls = 0

    def __call__(self):
        self.calls += 1
        return self.value


for ratio in (-0.2, 0):
    rng = Fixed(0)
    assert delay(100, ratio, rng) == 100
    assert rng.calls == 0

for ratio, expected in ((0.2, (80, 100, 120)),
                        (1, (0, 100, 200)),
                        (1.5, (0, 100, 200))):
    for u, want in zip((0, 0.5, 1), expected):
        rng = Fixed(u)
        assert math.isclose(delay(100, ratio, rng), want)
        assert rng.calls == 1

rng = Fixed(0.5)
assert delay(0, 0.2, rng) == 0
assert rng.calls == 0


def rejects(fn):
    try:
        fn()
    except ValueError:
        return
    raise AssertionError('invalid input accepted')


for ratio in (float('nan'), float('inf'), -float('inf')):
    rejects(lambda ratio=ratio: delay(100, ratio, Fixed(0.5)))
for base in (-1, float('nan'), float('inf')):
    rejects(lambda base=base: delay(base, 0.2, Fixed(0.5)))
for u in (-0.01, 1.01, float('nan')):
    rejects(lambda u=u: delay(100, 0.2, Fixed(u)))
rejects(lambda: delay(1e308, 1, Fixed(1)))
```
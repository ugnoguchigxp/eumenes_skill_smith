標準Pythonのみを使う設計例。未実行であり、将来、許可されたローカル環境でのみ実行する。外部通信・ファイル操作はない。ここでは区切りを1個に限定し、空白を削除せず拒否する仮契約を採用する。実APIの仕様やwindow識別機構を再現するものではない。window引数は信頼済みアダプターが生成した識別子を渡す前提で、応答は明示的な真偽値を返すダミーである。

```python
import unittest


def check(window, key, grants, external):
    if not isinstance(key, str):
        raise ValueError('Invalid permission key')
    parts = key.split(':')
    if len(parts) != 2:
        raise ValueError('Invalid permission key')
    if any(not p.strip() or p != p.strip() for p in parts):
        raise ValueError('Invalid permission key')
    if key not in grants.get(window, frozenset()):
        return False
    try:
        result = external(window, key)
    except Exception:
        return False
    return result is True


class BoundaryTests(unittest.TestCase):
    def test_invalid_never_calls_external(self):
        calls = []
        def external(window, key):
            calls.append((window, key))
            return True
        for key in (None, 7, '', ':', ':read', 'doc:',
                    ' :read', 'doc: ', 'doc', 'doc:read:all',
                    ' doc:read', 'doc:read '):
            with self.subTest(key=key):
                with self.assertRaisesRegex(ValueError,
                                            'Invalid permission key'):
                    check('a', key, {}, external)
        self.assertEqual(calls, [])

    def test_window_isolation(self):
        calls = []
        grants = {'a': frozenset({'doc:read'})}
        def external(window, key):
            calls.append((window, key))
            return True
        self.assertFalse(check('b', 'doc:read', grants, external))
        self.assertFalse(check(None, 'doc:read', grants, external))
        self.assertEqual(calls, [])
        self.assertTrue(check('a', 'doc:read', grants, external))
        self.assertEqual(calls, [('a', 'doc:read')])
        self.assertFalse(check('b', 'doc:read', grants, external))
        self.assertEqual(len(calls), 1)

    def test_not_explicitly_allowed(self):
        grants = {'a': frozenset({'doc:read'})}
        for result in (False, None, 'true', 1):
            with self.subTest(result=result):
                self.assertFalse(check('a', 'doc:read', grants,
                                       lambda w, k: result))
        def failed(window, key):
            raise RuntimeError('offline failure')
        self.assertFalse(check('a', 'doc:read', grants, failed))


if __name__ == '__main__':
    unittest.main()
```

期待値は全テスト成功・終了コード0。不正キーを通す、またはwindow別の包含判定を外す意図的な違反ではテストが失敗する設計である。実APIの応答スキーマ、送信元偽装、実際の保護対象処理は別途統合試験が必要。
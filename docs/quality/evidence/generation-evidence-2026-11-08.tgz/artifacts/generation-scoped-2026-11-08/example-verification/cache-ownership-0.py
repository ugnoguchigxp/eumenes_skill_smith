import json


def service_cache_address(tenant_id, order_id, revision):
    if not all(isinstance(x, str) and x for x in (tenant_id, order_id)):
        raise ValueError("nonempty string IDs required")
    if type(revision) is not int or revision < 0:
        raise ValueError("nonnegative integer revision required")
    namespace = "order-summary:v1"
    key = json.dumps(
        [tenant_id, order_id, revision],
        ensure_ascii=True, separators=(",", ":")
    )
    return namespace, key


address = service_cache_address("t1", "o1", 3)
expected = ("order-summary:v1", '["t1","o1",3]')
assert address == expected
assert service_cache_address("t1", "o1", 3) == address
assert service_cache_address("t2", "o1", 3) != address
assert service_cache_address("t1", "o2", 3) != address
assert service_cache_address("t1", "o1", 4) != address

# 単純な区切り文字連結では衝突する組も区別する。
a = service_cache_address("a:b", "c", 0)
b = service_cache_address("a", "b:c", 0)
assert a != b
assert json.loads(a[1]) == ["a:b", "c", 0]

# 名前空間と生成済みキーだけで値を識別できる。
store = {address: "summary-a", a: "summary-b"}
assert store[address] == "summary-a"
assert service_cache_address("t2", "o1", 3) not in store

# 負例は必ず拒否されることを期待する。
for args in [("", "o1", 3), ("t1", "o1", -1), ("t1", "o1", True)]:
    try:
        service_cache_address(*args)
    except ValueError:
        pass
    else:
        raise AssertionError("invalid input accepted")

print("fixture passed")

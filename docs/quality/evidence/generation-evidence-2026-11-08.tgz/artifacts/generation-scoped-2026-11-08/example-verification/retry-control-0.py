from math import isfinite

# 設計例の値。対象環境の推奨値ではない。
def decide(kind, now, attempt, age, u=0.5, hint=None):
    assert attempt >= 1 and age >= 0 and 0 <= u <= 1
    assert isfinite(now) and isfinite(age)
    if kind == 'invalid':
        return ('quarantine', None)
    if kind != '429':
        return ('review', None)
    if attempt >= 4 or age >= 60:
        return ('exhausted', None)
    if hint is not None and (not isfinite(hint) or hint < 0):
        return ('review', None)
    backoff = min(16, 2 * 2 ** min(attempt - 1, 3))
    delay = max(1, backoff * u, hint or 0)
    if age + delay >= 60:
        return ('exhausted', None)
    return ('waiting', now + delay)

def eligible(decision, now):
    state, due = decision
    return state == 'waiting' and due is not None and now >= due

# 正例: サーバー下限を尊重し、期限到達時だけ取得可能。
d = decide('429', 100, 1, 0, u=0.5, hint=7)
assert d == ('waiting', 107)
assert not eligible(d, 106)
assert eligible(d, 107)
# 負例: 恒久不備・不明エラー・上限超過を取得しない。
for kind, attempt, age in [('invalid', 1, 0),
                           ('unknown', 1, 0),
                           ('429', 4, 0), ('429', 1, 59)]:
    result = decide(kind, 100, attempt, age)
    assert not eligible(result, 1000)
assert decide('429', 100, 1, 0, hint=-1)[0] == 'review'
# 下限と指数増加上限の境界。
assert decide('429', 100, 1, 0, u=0) == ('waiting', 101)
assert decide('429', 100, 3, 0, u=1) == ('waiting', 108)

import assert from 'node:assert/strict';

async function dispatch(result, injected, fallback) {
  const selected = injected === undefined ? fallback : injected;
  return await selected(result);
}

const result = Object.freeze({ reviewId: 'fixture', accepted: true });
const calls = [];
const injected = async value => {
  calls.push(['injected', value]);
  return 'injected-ok';
};
const fallback = async value => {
  calls.push(['default', value]);
  return 'default-ok';
};

assert.equal(await dispatch(result, injected, fallback), 'injected-ok');
assert.deepEqual(calls.map(([name]) => name), ['injected']);
assert.strictEqual(calls[0][1], result);

calls.length = 0;
assert.equal(await dispatch(result, undefined, fallback), 'default-ok');
assert.deepEqual(calls.map(([name]) => name), ['default']);
assert.strictEqual(calls[0][1], result);

for (const asyncFailure of [false, true]) {
  calls.length = 0;
  const failure = new Error('fixture failure');
  const fail = value => {
    calls.push(['injected', value]);
    if (asyncFailure) return Promise.reject(failure);
    throw failure;
  };
  await assert.rejects(dispatch(result, fail, fallback), e => e === failure);
  assert.deepEqual(calls.map(([name]) => name), ['injected']);
}

// 禁止する二重呼出を、同じ排他条件が検出する負例。
calls.length = 0;
await injected(result);
await fallback(result);
assert.throws(
  () => assert.deepEqual(calls.map(([name]) => name), ['injected']),
  { name: 'AssertionError' }
);

import io
import zipfile

def fixture(entries):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w') as archive:
        for name, content in entries:
            archive.writestr(name, content)
    return buffer.getvalue()

def acceptable(data):
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            files = [x for x in archive.infolist() if not x.is_dir()]
            return (
                archive.testzip() is None
                and len(files) == 1
                and files[0].filename.endswith('.sql')
                and files[0].file_size > 0
            )
    except (zipfile.BadZipFile, RuntimeError, OSError):
        return False

cases = [
    (fixture([('backup.sql', b'SELECT 1;')]), True),
    (fixture([('backup.sql', b'')]), False),
    (fixture([('backup.txt', b'data')]), False),
    (fixture([('a.sql', b'x'), ('b.sql', b'y')]), False),
    (b'not a zip', False),
]
for data, expected in cases:
    assert acceptable(data) == expected
print('5件の期待値に一致')

from copy import deepcopy

before = {1: {"status": "old"}, 2: {"status": "keep"}}
expected = {1: {"status": "new"}, 2: {"status": "keep"}}
approved_ids = {1}

def matches(actual):
    changed = {k for k in set(before) | set(actual)
               if before.get(k) != actual.get(k)}
    return actual == expected and changed == approved_ids

good = deepcopy(expected)
bad_value = deepcopy(expected)
bad_value[1]["status"] = "wrong"
bad_scope = deepcopy(expected)
bad_scope[2]["status"] = "changed"
bad_missing = deepcopy(expected)
del bad_missing[1]

assert matches(good) is True
assert matches(bad_value) is False
assert matches(bad_scope) is False
assert matches(bad_missing) is False
print("合成差分の正例1件・負例3件が期待どおり")

from copy import deepcopy

# 合成入力。アプリの実際の必要権限を表すものではない。
required = {
    'editor': {('filesystem', 'read', 'workspace')},
    'preview': set(),
}

def differences(candidate):
    problems = []
    if set(candidate) != set(required):
        problems.append('window-mismatch')
    for window in set(candidate) | set(required):
        actual = candidate.get(window, set())
        wanted = required.get(window, set())
        if actual - wanted:
            problems.append('extra:' + window)
        if wanted - actual:
            problems.append('missing:' + window)
    return sorted(problems)

# 正例の期待値: 差分なし。
assert differences(deepcopy(required)) == []

# 負例: 他windowへの漏出、必要権限の欠落、対象範囲の拡大。
leaked = deepcopy(required)
leaked['preview'].add(('filesystem', 'read', 'workspace'))
assert differences(leaked) == ['extra:preview']
missing = deepcopy(required)
missing['editor'].clear()
assert differences(missing) == ['missing:editor']
broad = deepcopy(required)
broad['editor'] = {('filesystem', 'read', '*')}
assert differences(broad) == ['extra:editor', 'missing:editor']
unknown = deepcopy(required)
unknown['unlisted'] = set()
assert differences(unknown) == ['window-mismatch']
print('集合照合例の期待値と一致')

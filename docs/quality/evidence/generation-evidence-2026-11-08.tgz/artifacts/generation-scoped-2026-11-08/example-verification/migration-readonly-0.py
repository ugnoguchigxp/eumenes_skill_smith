import json

fixture = json.loads('''{
  "today": ["plan"],
  "future_preflight": ["backup", "counts", "dry_run"],
  "cutover_approved": false
}''')

def valid_boundary(plan):
    return (
        plan["today"] == ["plan"]
        and set(plan["future_preflight"]) <= {"backup", "counts", "dry_run"}
        and plan["cutover_approved"] is False
    )

assert valid_boundary(fixture) is True
for forbidden in ("stop_daemon", "write_migration", "drop_old_tables"):
    bad = dict(fixture, today=["plan", forbidden])
    assert valid_boundary(bad) is False
bad = dict(fixture, future_preflight=["counts", "write_migration"])
assert valid_boundary(bad) is False
assert valid_boundary(dict(fixture, cutover_approved=True)) is False
print("文書境界fixture合格")

import json

fixture = json.loads('''{
  "allowed_module": "target",
  "cases": [
    {"changes": [{"module": "target", "kind": "edit", "bug_related": true}], "expected": true},
    {"changes": [{"module": "other", "kind": "edit", "bug_related": true}], "expected": false},
    {"changes": [{"module": "target", "kind": "move", "bug_related": true}], "expected": false},
    {"changes": [{"module": "target", "kind": "edit", "bug_related": false}], "expected": false}
  ]
}''')

def within_fix_scope(changes, allowed_module):
    return bool(changes) and all(
        c['module'] == allowed_module
        and c['kind'] == 'edit'
        and c['bug_related'] is True
        for c in changes
    )

for case in fixture['cases']:
    actual = within_fix_scope(case['changes'], fixture['allowed_module'])
    assert actual is case['expected'], (case, actual)
print('4件の合成判定が期待値と一致')
